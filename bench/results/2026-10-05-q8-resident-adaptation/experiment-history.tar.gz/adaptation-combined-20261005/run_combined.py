"""Build frozen integration source, check ownership fixtures, then screen privately."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tarfile
import time

root=Path.home()/'fleet-downloads/adaptation-combined-20261005'
state={'phase':'starting','started_unix':time.time(),'commands':[]}
def save(**kw):
    state.update(kw)
    p=root/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'status.json')
def run(label,args,env=None):
    save(phase=label); start=time.monotonic()
    with (root/(label+'.log')).open('x') as log:
        rc=subprocess.run([str(x) for x in args],stdout=log,stderr=subprocess.STDOUT,env=env).returncode
    state['commands'].append({'label':label,'exit_code':rc,'seconds':time.monotonic()-start})
    save()
    if rc:raise RuntimeError(label+' failed: '+str(rc))
try:
    save()
    source,build=root/'source',root/'build';source.mkdir(exist_ok=False)
    with tarfile.open(root/'source.tar.gz') as a:a.extractall(source,filter='data')
    env=dict(os.environ,CCACHE_BASEDIR=str(root),CCACHE_NOHASHDIR='true')
    run('configure',['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
        '-DSTRATA_ENABLE_CUDA=ON','-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=120',
        '-DCMAKE_CXX_COMPILER_LAUNCHER=ccache','-DCMAKE_CUDA_COMPILER_LAUNCHER=ccache','-DSTRATA_NATIVE_EXPERTS=ON',
        '-DSTRATA_BUILD_TESTS=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON',
        '-DSTRATA_GGML_DIR='+str(Path.home()/'fleet-downloads/strata-rotation-mvp-ab-20261004/ggml-3cf03257')],env)
    run('build',['cmake','--build',build,'--parallel','4','--target','strata','file_expert_source_test',
                 'exchange_storage_test','duplex_exchange_test'],env)
    save(engine_sha256=hashlib.file_digest((build/'strata').open('rb'),'sha256').hexdigest())
    lock=(Path.home()/'fleet-downloads/.rtxpro-bandwidth.lock').open('a+')
    save(phase='waiting_for_gpu_lock')
    fcntl.flock(lock,fcntl.LOCK_EX)
    service_args=['systemctl','show','strata-q8-lan.service','--property=ActiveState,UnitFileState,RefuseManualStart,MainPID']
    service=subprocess.check_output(service_args,text=True)
    assert all(x in service for x in ['ActiveState=inactive','UnitFileState=disabled','RefuseManualStart=yes','MainPID=0'])
    busy=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert not busy,'GPU occupied by an unrelated job: '+busy
    state['memlock_before']=resource.getrlimit(resource.RLIMIT_MEMLOCK)
    subprocess.run(['sudo','-n','prlimit','--pid',str(os.getpid()),'--memlock=unlimited:unlimited'],check=True)
    state['memlock_after']=resource.getrlimit(resource.RLIMIT_MEMLOCK)
    run('ctest',['ctest','--test-dir',build,'-R','^(file_expert_source_test|exchange_storage_test|duplex_exchange_test)$','--output-on-failure'])
    py=Path.home()/'src/Strata/.venv/bin/python'
    for name in ['q2-gate','q8-screen']:
        run(name,[py,'-u',root/'bench_combined.py',root/(name+'-plan.json'),root/name])
    assert subprocess.check_output(service_args,text=True)==service
    save(phase='complete',completed=True,finished_unix=time.time())
except BaseException as exc:
    save(phase='failed',error=repr(exc),finished_unix=time.time());raise
