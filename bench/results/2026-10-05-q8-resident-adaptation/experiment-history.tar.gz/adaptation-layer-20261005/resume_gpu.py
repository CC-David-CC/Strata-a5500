"""Build frozen integration source, check ownership fixtures, then screen privately."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tarfile
import time

root=Path.home()/'fleet-downloads/adaptation-layer-20261005'
state={'phase':'starting','started_unix':time.time(),'commands':[]}
def save(**kw):
    state.update(kw)
    p=root/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'status.json')
def run(label,args,env=None):
    save(phase=label); start=time.monotonic()
    with (root/(label+'.log')).open('x') as log:
        rc=subprocess.run([str(x) for x in args],stdout=log,stderr=subprocess.STDOUT,env=env).returncode
    state['commands'].append({'label':label,'exit_code':rc,'seconds':time.monotonic()-start})
    save()
    if rc:raise RuntimeError(label+' failed: '+str(rc))
try:
    state=json.loads((root/'status.json').read_text())
    build=root/'build'
    lock=(Path.home()/'fleet-downloads/.rtxpro-bandwidth.lock').open('a+')
    save(phase='waiting_for_gpu_lock')
    # Run DeepGEMM's bounded stage screen before this next GPU group.
    save(phase='waiting_for_deepgemm_stage_screen')
    dg=Path.home()/'fleet-downloads/deepgemm-sm120-20261005/gpu-status.json'
    while True:
        if dg.exists() and json.loads(dg.read_text()).get('phase') in ['complete','failed']: break
        time.sleep(5)
    save(phase='waiting_for_gpu_lock')
    fcntl.flock(lock,fcntl.LOCK_EX)
    service_args=['systemctl','show','strata-q8-lan.service','--property=ActiveState,UnitFileState,RefuseManualStart,MainPID']
    service=subprocess.check_output(service_args,text=True)
    assert all(x in service for x in ['ActiveState=inactive','UnitFileState=disabled','RefuseManualStart=yes','MainPID=0'])
    busy=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert not busy,'GPU occupied by an unrelated job: '+busy
    state['memlock_before']=resource.getrlimit(resource.RLIMIT_MEMLOCK)
    subprocess.run(['sudo','-n','prlimit','--pid',str(os.getpid()),'--memlock=unlimited:unlimited'],check=True)
    state['memlock_after']=resource.getrlimit(resource.RLIMIT_MEMLOCK)
    run('ctest',['ctest','--test-dir',build,'-R','^(file_expert_source_test|exchange_storage_test|duplex_exchange_test|layer_exchange_test)$','--output-on-failure'])
    py=Path.home()/'src/Strata/.venv/bin/python'
    for name in ['q2-gate','q8-screen']:
        run(name,[py,'-u',root/'bench_combined.py',root/(name+'-plan.json'),root/name])
    assert subprocess.check_output(service_args,text=True)==service
    save(phase='complete',completed=True,finished_unix=time.time())
except BaseException as exc:
    save(phase='failed',error=repr(exc),finished_unix=time.time());raise
