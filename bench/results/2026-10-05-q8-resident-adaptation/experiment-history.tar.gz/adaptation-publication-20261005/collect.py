"""Archive only this experiment's scripts, receipts, prompt IDs and logs."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path.home() / 'fleet-downloads'
dest = root / 'adaptation-publication-20261005'
names = ['async-locked-20261005', 'adaptation-combined-20261005',
         'adaptation-layer-20261005', 'adaptation-no-rotation-20261005',
         'adaptation-publication-20261005']
manifest = []
with tarfile.open(dest / 'experiment-history.tar.gz', 'w:gz') as out:
    for name in names:
        p = root / name
        state = json.loads((p / 'status.json').read_text())
        assert state.get('completed') or state.get('phase') == 'complete', (name, state)
        for q in sorted(p.iterdir()):
            files = sorted(q.rglob('*')) if q.name in ['model', 'q2-gate', 'q8-screen'] else [q]
            for f in files:
                if not f.is_file() or f.suffix not in ['.py', '.json', '.log']:
                    continue
                rel = str(f.relative_to(root)).replace('\\', '/')
                manifest.append({'path': rel, 'bytes': f.stat().st_size,
                                 'sha256': hashlib.file_digest(f.open('rb'), 'sha256').hexdigest()})
                out.add(f, arcname=rel)
        archive = p / 'source.tar.gz'
        if archive.exists():
            manifest.append({'path': name + '/source.tar.gz', 'included': False,
                             'note': 'Source is retained in the implementation commit history.',
                             'sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()})
(dest / 'history-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Archived', len(manifest), 'receipts:', (dest / 'experiment-history.tar.gz').stat().st_size, 'bytes')
