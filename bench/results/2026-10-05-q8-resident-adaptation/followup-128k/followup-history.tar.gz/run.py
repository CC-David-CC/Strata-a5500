import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

root = Path.home() / 'fleet-downloads/adaptation-post-publication-898-20261005'
build = Path.home() / 'fleet-downloads/adaptation-no-rotation-20261005/build'
state = {'phase': 'starting', 'started_unix': time.time(), 'commands': []}
def save(**kw):
    state.update(kw)
    p = root / 'status.tmp'
    p.write_text(json.dumps(state, indent=2) + '\n')
    p.replace(root / 'status.json')
def run(label, args):
    save(phase=label)
    start = time.monotonic()
    with (root / (label + '.log')).open('x') as log:
        rc = subprocess.run([str(x) for x in args], stdout=log, stderr=subprocess.STDOUT).returncode
    state['commands'].append({'label': label, 'exit_code': rc, 'seconds': time.monotonic() - start})
    save()
    if rc:
        raise RuntimeError(label + ' failed: ' + str(rc))
try:
    save()
    expected = {
        build / 'strata': 'b791cefe332068c0ab3dab8c7c429c9d16ac2347898754a371bc19a38163996a',
        Path.home() / 'fleet-downloads/strata-q8-ple-reader-18d3da4/build/strata':
            'eb064c6c2b1a6681ff8e4e6ff26c0e72577f675306c362b53617c331c532fea1'}
    for path, sha in expected.items():
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == sha, path
    state['verified_binaries'] = {str(k): v for k, v in expected.items()}
    lock = (Path.home() / 'fleet-downloads/.rtxpro-bandwidth.lock').open('a+')
    save(phase='waiting_for_gpu_lock')
    fcntl.flock(lock, fcntl.LOCK_EX)
    service_args = ['systemctl', 'show', 'strata-q8-lan.service', '--property=ActiveState,UnitFileState,RefuseManualStart,MainPID']
    service = subprocess.check_output(service_args, text=True)
    assert all(x in service for x in ['ActiveState=inactive', 'UnitFileState=disabled', 'RefuseManualStart=yes', 'MainPID=0'])
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    state['memlock_before'] = resource.getrlimit(resource.RLIMIT_MEMLOCK)
    subprocess.run(['sudo', '-n', 'prlimit', '--pid', str(os.getpid()), '--memlock=unlimited:unlimited'], check=True)
    state['memlock_after'] = resource.getrlimit(resource.RLIMIT_MEMLOCK)
    py = Path.home() / 'src/Strata/.venv/bin/python'
    for name in ['q8-validation']:
        run(name, [py, '-u', root / 'bench_combined.py', root / (name + '-plan.json'), root / name])
    d = json.loads((root / 'q8-validation/result.json').read_text())
    recovery = d['runs'][1]['requests'][1]
    fresh = d['runs'][2]['requests'][0]
    keys = ['generated','prompt_read','drafts_accepted','drafts_offered','hits','lookups','ram_blobs','offloaded']
    state['recovery_comparison'] = {
        'tokens_identical': recovery['token_ids'] == fresh['token_ids'],
        'first_difference': next((i for i,(a,b) in enumerate(zip(recovery['token_ids'],fresh['token_ids'])) if a != b),None),
        'work_identical': all(recovery['timings'].get(k) == fresh['timings'].get(k) for k in keys),
        'qualification': 'Fresh versus post-cancellation smoke check; asynchronous placement can differ. This is not a full recurrent/KV state differential trace.'}
    assert subprocess.check_output(service_args, text=True) == service
    save(phase='complete', completed=True, finished_unix=time.time())
except BaseException as exc:
    save(phase='failed', error=repr(exc), finished_unix=time.time())
    raise
