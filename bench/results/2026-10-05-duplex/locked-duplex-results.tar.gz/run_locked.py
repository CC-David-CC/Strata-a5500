import fcntl
import json
import os
from pathlib import Path
import resource
import subprocess
import time

root=Path.home()/'fleet-downloads/duplex-locked-20261005'
state={'phase':'starting','started_unix':time.time()}
def save(**kw):
    state.update(kw)
    tmp=root/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(root/'status.json')
try:
    save()
    lock=(Path.home()/'fleet-downloads/.rtxpro-bandwidth.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    busy=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert not busy,busy
    service_args=['systemctl','show','strata-q8-lan.service','--property=ActiveState,UnitFileState,RefuseManualStart,MainPID']
    service=subprocess.check_output(service_args,text=True)
    assert all(x in service for x in ['ActiveState=inactive','UnitFileState=disabled','RefuseManualStart=yes','MainPID=0'])
    save(memlock_before=resource.getrlimit(resource.RLIMIT_MEMLOCK))
    subprocess.run(['sudo','-n','prlimit','--pid',str(os.getpid()),'--memlock=unlimited:unlimited'],check=True)
    save(memlock_after=resource.getrlimit(resource.RLIMIT_MEMLOCK),phase='model')
    assert resource.getrlimit(resource.RLIMIT_MEMLOCK)==(resource.RLIM_INFINITY,resource.RLIM_INFINITY)
    with (root/'model.log').open('x') as log:
        rc=subprocess.run([str(Path.home()/'src/Strata/.venv/bin/python'),'-u',str(root/'bench_locked.py'),
            str(root/'plan.json'),str(root/'model')],stdout=log,stderr=subprocess.STDOUT).returncode
    save(exit_code=rc)
    assert subprocess.check_output(service_args,text=True)==service
    if rc:raise RuntimeError('Locked memory check failed: '+str(rc))
    save(phase='complete',completed=True,finished_unix=time.time())
except BaseException as exc:
    save(phase='failed',error=repr(exc),finished_unix=time.time())
    raise
