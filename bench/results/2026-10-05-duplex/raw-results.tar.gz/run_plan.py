import fcntl
import os
from pathlib import Path
import subprocess
import sys

root = Path.home() / 'fleet-downloads/duplex-only-20261005'
lock = (Path.home() / 'fleet-downloads/.rtxpro-bandwidth.lock').open('a+')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
service = subprocess.check_output(['systemctl', 'show', 'strata-q8-lan.service',
    '--property=ActiveState,UnitFileState,RefuseManualStart,MainPID'], text=True)
assert all(x in service for x in ['ActiveState=inactive', 'UnitFileState=disabled', 'RefuseManualStart=yes', 'MainPID=0']), service
plan = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else plan
cmd = [str(Path.home() / 'src/Strata/.venv/bin/python'), '-u', str(root / 'bench_duplex.py'),
       str(root / (plan + '-plan.json')), str(root / out)]
result = subprocess.run(cmd)
assert subprocess.check_output(['systemctl', 'show', 'strata-q8-lan.service',
    '--property=ActiveState,UnitFileState,RefuseManualStart,MainPID'], text=True) == service
sys.exit(result.returncode)
